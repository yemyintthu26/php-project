<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<?php
error_reporting(1);
include("connection.php");
$img=$_FILES['img']['name'];
$prono=$_POST['t1'];
$price=$_POST['t2'];
if($_POST['sub'])
{$qry="INSERT INTO item(img,prod_no,price)VALUES('$img','$prono','$price')";
$result=mysql_query($qry) or die ("save items query fail.");
if($result)			
	   {mkdir("image/$i");
			move_uploaded_file($_FILES['img']['tmp_name'],"image/$i".$_FILES['img']['name']);	
  // move_uploaded_file($_FILES['file']['tmp_name'],"itempics/$itemno.jpg");
		
	    $err="<font size='+2'>item inserted successfully</font>";
	
		}
	else
	 {
	   echo "item is not inserted";
	   }
	}  
	mysql_close($con);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width-device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

        <title>Let's shop</title>
    </head>
    <body>
       <nav class="navbar">
        <div class="logo"><h1>Welcome Admin</h1></div>
            <ul class="menu">
                <li><a href="home.php" class="active">Home</a></li>
                <li><a href="product.php">Products</a></li>
                <li><a href="insert.php">insert</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
       </nav>
       <section class="content">
        <h1>Post your products now</h1>
    </section>

    <form name="testform" method="post" enctype="multipart/form-data" class="row gy-2 gx-3 align-items-center">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  
    <div class="col-auto">
    <label class="visually-hidden" for="autoSizingInputGroup">Image</label>
    <div class="input-group">
      <input type="file" name="img" class="form-control"  placeholder="Image">
    </div>
    <div class="col-auto">
    <label class="visually-hidden" for="autoSizingInput">Product Name</label>
    <input  name="t1" type="text" id="t1" class="form-control"  placeholder="Product Name">
  </div>
  <div class="col-auto">
    <label class="visually-hidden" for="autoSizingInput">Price</label>
    <input name="t2" type="text" id="t2" class="form-control"  placeholder="Price">
  </div>
  </div>
  <div class="col-auto">
    <button name="sub" type="submit" value="Submit" class="btn btn-primary">Submit</button>
  </div>
  <h2><?php echo $err;?></h2>
</form>
<?php }  ?>
<br><br><br>
    <footer>
        <p>Copyright at<a href="#">YMT@26</a></p>
    </footer>
    </body>
</html>