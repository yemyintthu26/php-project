<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width-device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Admin</title>
    </head>
    <body>
       <nav class="navbar">
        <div class="logo"><h1>Admin</h1></div>
            <ul class="menu">
                <li><a href="home.php" class="active">Home</a></li>
                <li><a href="product.php">Products</a></li>
                <li><a href="insert.php">Insert</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
       </nav>
    <h1 class="pheading">Our Latest Products</h1>
    <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("select * from item ");
						echo"<form method='post'><table style='border-color:#000000;border-style: dotted;margin-left:200px;' width='800px' align='center' ><tr><td>Image:</td><td>Product No:</td><td>Price:</td></tr>";
   $n=0;
    while($arr=mysql_fetch_array($sel))
   {
   $i=$arr['img'];
   
    if($n%1==0)
	{
	echo "<tr><tr>
	      ";
	}
   echo 
  "<td height='280' width='240' align='center'><img src='image/$i' height='200' width='200'></td>
 <b>
 <td>".$arr['prod_no'].
   "</td><td>".$arr['price'].
  "
   
   </td>";
  
  $n++;

   }
   	  echo "</tr></table>
       </form>";
	?>	
   

    <?php }  ?>

    
    <footer>
        <p>Copyright at<a href="#">YMT@26</a></p>
    </footer>
    </body>
</html>