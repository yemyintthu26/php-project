<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width-device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Mobile</title>
    </head>
    <body>
       <nav class="navbar">
        <div class="logo"><h1>Welcome Admin</h1></div>
            <ul class="menu">
                <li><a href="home.php" class="active">Home</a></li>
                <li><a href="product.php">Products</a></li>
                <li><a href="insert.php">insert</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
       </nav>
       <section class="content">
        <h1>This is admin panel</h1>
        <p>Admin dashboard is one of the core components of a control panel.</p>

    </body>
</html>